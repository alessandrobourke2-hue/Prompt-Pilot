import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';

const FRAMEWORKS = [
  {
    name: 'SWOT Analysis',
    description: 'Turns messy strategy into structured decisions.'
  },
  {
    name: 'Problem → Solution → Impact',
    description: 'Clarifies messaging.'
  },
  {
    name: 'Jobs To Be Done',
    description: 'Frames work around real user needs.'
  },
  {
    name: 'Product Requirements Structure',
    description: 'Turns ideas into clear specs.'
  },
  {
    name: 'Technical Debug Template',
    description: 'Systematic troubleshooting.'
  },
  {
    name: 'AIDA Framework',
    description: 'Guides attention to action.'
  }
];

const TESTIMONIALS = [
  {
    quote: "Turned my messy PRD into actual structure. Finally.",
    author: "Sarah Chen",
    role: "Product Lead"
  },
  {
    quote: "I use this before every ChatGPT session. Game changer.",
    author: "Marcus Reid",
    role: "Engineering Manager"
  },
  {
    quote: "My team stopped writing vague prompts. This works.",
    author: "Elena Vasquez",
    role: "Strategy Director"
  },
  {
    quote: "Built this into our workflow. Output quality went up 10x.",
    author: "David Park",
    role: "Head of Ops"
  }
];

export function FrameworkCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const [testimonialIndex, setTestimonialIndex] = useState(0);

  useEffect(() => {
    if (!isAutoPlaying) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % FRAMEWORKS.length);
    }, 3500);

    return () => clearInterval(interval);
  }, [isAutoPlaying]);

  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % TESTIMONIALS.length);
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  const goToNext = () => {
    setIsAutoPlaying(false);
    setCurrentIndex((prev) => (prev + 1) % FRAMEWORKS.length);
  };

  const goToPrev = () => {
    setIsAutoPlaying(false);
    setCurrentIndex((prev) => (prev - 1 + FRAMEWORKS.length) % FRAMEWORKS.length);
  };

  return (
    <section className="w-full py-24 bg-gray-50/50 border-y border-gray-100">
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left: Framework Carousel */}
          <div>
            {/* Headline */}
            <h2 className="font-serif text-4xl md:text-5xl font-medium text-gray-900 mb-16 text-center lg:text-left">
              Structured by design.
            </h2>

            {/* Carousel */}
            <div className="relative">
              <div className="min-h-[180px] flex items-center justify-center lg:justify-start">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentIndex}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.4 }}
                    className="text-center lg:text-left"
                  >
                    <h3 className="font-serif text-3xl md:text-4xl font-medium text-gray-900 mb-4">
                      {FRAMEWORKS[currentIndex].name}
                    </h3>
                    <p className="text-lg md:text-xl text-gray-500 font-light">
                      {FRAMEWORKS[currentIndex].description}
                    </p>
                  </motion.div>
                </AnimatePresence>
              </div>

              {/* Navigation */}
              <div className="flex items-center justify-center lg:justify-start gap-6 mt-12">
                <button
                  onClick={goToPrev}
                  className="p-2 rounded-full hover:bg-gray-100 transition-colors"
                  aria-label="Previous framework"
                >
                  <ChevronLeft size={24} className="text-gray-600" />
                </button>

                {/* Dots */}
                <div className="flex items-center gap-2">
                  {FRAMEWORKS.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => {
                        setIsAutoPlaying(false);
                        setCurrentIndex(index);
                      }}
                      className={`h-2 rounded-full transition-all ${
                        index === currentIndex
                          ? 'w-8 bg-gray-900'
                          : 'w-2 bg-gray-300 hover:bg-gray-400'
                      }`}
                      aria-label={`Go to framework ${index + 1}`}
                    />
                  ))}
                </div>

                <button
                  onClick={goToNext}
                  className="p-2 rounded-full hover:bg-gray-100 transition-colors"
                  aria-label="Next framework"
                >
                  <ChevronRight size={24} className="text-gray-600" />
                </button>
              </div>
            </div>
          </div>

          {/* Right: Rotating Testimonials */}
          <div className="relative">
            <div className="min-h-[300px] flex items-center">
              <AnimatePresence mode="wait">
                <motion.div
                  key={testimonialIndex}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.5 }}
                  className="bg-white rounded-3xl p-8 shadow-[0_8px_30px_rgba(0,0,0,0.06)] border border-gray-100"
                >
                  {/* Stars */}
                  <div className="flex items-center gap-1 mb-6">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} size={18} className="fill-black text-black" />
                    ))}
                  </div>

                  {/* Quote */}
                  <p className="text-lg md:text-xl font-medium text-gray-900 mb-6 leading-relaxed">
                    "{TESTIMONIALS[testimonialIndex].quote}"
                  </p>

                  {/* Author */}
                  <div className="border-t border-gray-100 pt-6">
                    <p className="font-semibold text-gray-900">
                      {TESTIMONIALS[testimonialIndex].author}
                    </p>
                    <p className="text-sm text-gray-500 mt-1">
                      {TESTIMONIALS[testimonialIndex].role}
                    </p>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}