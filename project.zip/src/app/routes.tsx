import { createBrowserRouter } from "react-router";
import { LandingPage } from "./pages/LandingPage";
import { PromptInputPage } from "./pages/PromptInputPage";
import { ProcessingPage } from "./pages/ProcessingPage";
import { ResultsPage } from "./pages/ResultsPage";
import { DashboardPage } from "./pages/DashboardPage";
import { OnboardingPage } from "./pages/OnboardingPage";
import { DesignSystemPage } from "./pages/DesignSystemPage";
import { PricingPage } from "./pages/PricingPage";
import { CommandCenter } from "./pages/CommandCenterNew";
import { 
  Workflows,
  HistoryPage,
  UsagePage,
  AccountPage
} from "./pages/PlaceholderPages";
import { PromptLibrary } from "./pages/PromptLibraryNew";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <LandingPage />,
  },
  {
    path: "/pricing",
    element: <PricingPage />,
  },
  {
    path: "/onboarding",
    element: <OnboardingPage />,
  },
  {
    path: "/input",
    element: <PromptInputPage />,
  },
  {
    path: "/processing",
    element: <ProcessingPage />,
  },
  {
    path: "/results",
    element: <ResultsPage />,
  },
  {
    path: "/dashboard",
    element: <DashboardPage />,
  },
  {
    path: "/design-system",
    element: <DesignSystemPage />,
  },
  // New authenticated app routes
  {
    path: "/app",
    element: <CommandCenter />,
  },
  {
    path: "/app/input",
    element: <PromptInputPage />,
  },
  {
    path: "/app/library",
    element: <PromptLibrary />,
  },
  {
    path: "/app/workflows",
    element: <Workflows />,
  },
  {
    path: "/app/history",
    element: <HistoryPage />,
  },
  {
    path: "/app/usage",
    element: <UsagePage />,
  },
  {
    path: "/app/account",
    element: <AccountPage />,
  },
]);