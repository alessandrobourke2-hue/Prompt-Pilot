import React from 'react';
import * as ReactRouter from 'react-router';
const { Link, useLocation } = ReactRouter;
import { 
  Home, 
  Library, 
  Workflow, 
  History, 
  BarChart3, 
  User, 
} from 'lucide-react';

// Shared Left Rail Navigation
function LeftRail() {
  const location = useLocation();
  
  const navItems = [
    { path: '/app', label: 'Command Center', icon: Home },
    { path: '/app/library', label: 'Prompt Library', icon: Library },
    { path: '/app/workflows', label: 'Workflows', icon: Workflow },
    { path: '/app/history', label: 'History', icon: History },
    { path: '/app/usage', label: 'Usage', icon: BarChart3 },
  ];

  const isActive = (path: string) => {
    if (path === '/app') {
      return location.pathname === '/app';
    }
    return location.pathname.startsWith(path);
  };

  return (
    <div className="fixed left-0 top-0 h-screen w-60 bg-[#0F1115] flex flex-col">
      {/* Top */}
      <div className="p-6 border-b border-gray-800">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-7 h-7 bg-white rounded-lg flex items-center justify-center text-black font-serif font-bold text-lg">
            P
          </div>
          <span className="font-serif font-bold text-lg text-white">PromptPilot</span>
        </div>
        <p className="text-xs text-gray-500 uppercase tracking-wider font-medium">
          Operator Environment
        </p>
      </div>

      {/* Primary Nav */}
      <nav className="flex-1 px-3 py-6 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = isActive(item.path);
          
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all relative ${
                active
                  ? 'text-white bg-white/5 shadow-[inset_2px_0_0_0_rgba(255,255,255,0.8)]'
                  : 'text-gray-400 hover:text-gray-200 hover:bg-white/5'
              }`}
            >
              <Icon size={18} />
              {item.label}
            </Link>
          );
        })}
      </nav>

      {/* Bottom */}
      <div className="p-3 border-t border-gray-800 space-y-1">
        <Link
          to="/app/account"
          className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
            location.pathname === '/app/account'
              ? 'text-white bg-white/5'
              : 'text-gray-400 hover:text-gray-200 hover:bg-white/5'
          }`}
        >
          <User size={18} />
          Account
        </Link>
        
        <div className="mt-3 px-3 py-2 bg-white/5 rounded-lg border border-gray-800">
          <p className="text-xs text-gray-500 mb-1">Plan</p>
          <div className="flex items-center justify-between">
            <p className="text-sm font-semibold text-white">Free</p>
            <Link to="/pricing" className="text-xs font-medium text-blue-400 hover:text-blue-300 transition-colors">
              Upgrade
            </Link>
          </div>
        </div>

        <div className="px-3 py-2">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-500"></div>
            <p className="text-xs text-gray-500">Extension Connected</p>
          </div>
        </div>
      </div>
    </div>
  );
}

// Shared Top Bar
function TopBar({ title, subtitle }: { title: string; subtitle: string }) {
  return (
    <div className="border-b border-gray-200 bg-white px-8 py-6">
      <h1 className="text-2xl font-serif font-bold text-gray-900">{title}</h1>
      <p className="text-sm text-gray-600 mt-1">{subtitle}</p>
    </div>
  );
}

// Placeholder pages
export function Workflows() {
  return (
    <div className="min-h-screen bg-[#FAFAFA]">
      <LeftRail />
      <div className="ml-60">
        <TopBar title="Workflows" subtitle="Create and manage prompt workflows" />
        <div className="p-8">
          <div className="max-w-4xl mx-auto text-center py-20">
            <Workflow size={64} className="mx-auto mb-4 text-gray-400" />
            <h2 className="text-xl font-serif font-bold text-gray-800 mb-2">Workflows Coming Soon</h2>
            <p className="text-gray-600">Chain multiple prompts together into automated workflows.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export function HistoryPage() {
  return (
    <div className="min-h-screen bg-[#FAFAFA]">
      <LeftRail />
      <div className="ml-60">
        <TopBar title="History" subtitle="View your enhancement history" />
        <div className="p-8">
          <div className="max-w-4xl mx-auto text-center py-20">
            <History size={64} className="mx-auto mb-4 text-gray-400" />
            <h2 className="text-xl font-serif font-bold text-gray-800 mb-2">History Coming Soon</h2>
            <p className="text-gray-600">View and search through all your enhanced prompts.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export function UsagePage() {
  return (
    <div className="min-h-screen bg-[#FAFAFA]">
      <LeftRail />
      <div className="ml-60">
        <TopBar title="Usage" subtitle="Monitor your usage and plan details" />
        <div className="p-8">
          <div className="max-w-4xl mx-auto text-center py-20">
            <BarChart3 size={64} className="mx-auto mb-4 text-gray-400" />
            <h2 className="text-xl font-serif font-bold text-gray-800 mb-2">Usage Analytics Coming Soon</h2>
            <p className="text-gray-600">Track your prompt enhancements and API usage.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export function AccountPage() {
  return (
    <div className="min-h-screen bg-[#FAFAFA]">
      <LeftRail />
      <div className="ml-60">
        <TopBar title="Account" subtitle="Manage your account settings" />
        <div className="p-8">
          <div className="max-w-4xl mx-auto text-center py-20">
            <User size={64} className="mx-auto mb-4 text-gray-400" />
            <h2 className="text-xl font-serif font-bold text-gray-800 mb-2">Account Settings Coming Soon</h2>
            <p className="text-gray-600">Manage your profile, billing, and preferences.</p>
          </div>
        </div>
      </div>
    </div>
  );
}